package com.restapi.restapi.controller;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import jakarta.annotation.PostConstruct;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class FileService {

    @Value("${file.base-directory}")
    private String baseDirectory;
    
 // Map to store filename and its corresponding path
    private final Map<String, Path> fileMap = new HashMap<>();

    @PostConstruct
    public void initializeFileMap() {
        // Initialize the map by scanning the base directory and its subdirectories
        try {
            preloadFileMap(baseDirectory);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }
    }
    
    private void preloadFileMap(String directory) throws IOException {
        Path dir = Paths.get(directory);

        if (Files.exists(dir) && Files.isDirectory(dir)) {
            // Walk the file tree starting from the root directory and include all nested directories
            Files.walk(dir)
                 .filter(Files::isRegularFile)
                 .filter(path -> path.toString().endsWith(".json")) // Ensure only .json files are included
                 .forEach(path -> fileMap.put(path.getFileName().toString(), path));
        }
        
        /*for (Map.Entry<String, Path> entry : fileMap.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }*/
    }

    public String readFileContent(String filename) throws IOException {
        Path file = ResourceUtils.getFile(baseDirectory + filename+".json").toPath();
        //Path file1 = ResourceUtils.getFile("D:\\SDUI\\abc.json").toPath();
        
        return new String(Files.readAllBytes(file));
    }
    
    
    public String readScreenContent(String filename) throws IOException {
             
    	
        Path file = fileMap.get(filename+".json");

        if (file == null) {
            throw new IOException("File not found: " + filename);
        }

        return new String(Files.readAllBytes(file));
    }
}
