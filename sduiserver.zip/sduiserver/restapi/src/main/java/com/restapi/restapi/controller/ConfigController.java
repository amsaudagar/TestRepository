package com.restapi.restapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/config")
public class ConfigController {

    @Autowired
    private MockConfigService mockConfigService;

    @GetMapping("/updateStatus")
    public ResponseEntity<String> updateStatus(@RequestParam String endpoint, @RequestParam Integer status) {
        if (status < 100 || status > 599) {
            return ResponseEntity.badRequest().body("Invalid HTTP status code provided.");
        }
        try {
            mockConfigService.updateResponseStatus(endpoint, status);
            return ResponseEntity.ok("Status updated successfully for " + endpoint);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error updating status: " + e.getMessage());
        }
    }
}

