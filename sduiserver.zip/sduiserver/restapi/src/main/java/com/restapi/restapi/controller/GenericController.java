package com.restapi.restapi.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1")
public class GenericController {

    @Autowired
    private FileService fileService;

    @Autowired
    private MockConfigService mockConfigService;
    

    
    private ResponseEntity<String> getResponse(String fullPath) {
    	try {
    		
            Optional<Integer> configuredStatus = mockConfigService.getResponseStatus(fullPath);

            String content = fileService.readScreenContent(fullPath);
            //String content = fileService.readFileContent(fullPath);
            
            if (configuredStatus.isPresent() && configuredStatus.get() != 200) {
                return ResponseEntity.status(HttpStatus.valueOf(configuredStatus.get()))
                                     .body(content);
            }
            
            
            return ResponseEntity.ok(content);
        } catch (Exception e) {
            e.printStackTrace();  // Log the error
            return ResponseEntity.badRequest().body("Error reading file: " + e.getMessage());
        }
    }
    
    @GetMapping("/{resource}")
    public ResponseEntity<String> getGenericResource(@PathVariable String resource) {
    	String fullPath = "/v1/" + resource;
    	return getResponse(resource);
    }

    @GetMapping("/{resource}/{resource2}")
    public ResponseEntity<String> getGenericResource1(@PathVariable String resource, 
    		@PathVariable String resource2) {
    	String fullPath = "/v1/"+resource+"/"+resource2;

    	return getResponse(resource2);
    }
    

    @GetMapping("/{resource}/{resource2}/{resource3}")
    public ResponseEntity<String> getGenericResource2(@PathVariable String resource, 
    		@PathVariable String resource2,
    		@PathVariable String resource3) {
    	String fullPath = "/v1/"+resource+"/"+resource2 + "/" + resource3;

    	return getResponse(resource3);
    }
    

    @PostMapping("/{resource}")
    public ResponseEntity<String> postGenericResource(@PathVariable String resource) {
    	String fullPath = "/v1/" + resource;
    	return getResponse(resource);
    }
    

    @PostMapping("/{resource}/{resource2}")
    public ResponseEntity<String> postGenericResource1(@PathVariable String resource, 
    		@PathVariable String resource2) {
    	String fullPath = "/v1/"+resource+"/"+resource2;

    	return getResponse(resource2);
    }
    

    @PostMapping("/{resource}/{resource2}/{resource3}")
    public ResponseEntity<String> postGenericResource2(@PathVariable String resource, 
    		@PathVariable String resource2,
    		@PathVariable String resource3) {
    	String fullPath = "/v1/"+resource+"/"+resource2 + "/" + resource3;

    	return getResponse(resource3);
    }
    
    /*private ResponseEntity<String> getResponse(String fullPath) {
    	try {
    		
            Optional<Integer> configuredStatus = mockConfigService.getResponseStatus(fullPath);

            String content = fileService.readFileContent(fullPath);
            
            if (configuredStatus.isPresent() && configuredStatus.get() != 200) {
                return ResponseEntity.status(HttpStatus.valueOf(configuredStatus.get()))
                                     .body(content);
            }
            
            
            return ResponseEntity.ok(content);
        } catch (Exception e) {
            e.printStackTrace();  // Log the error
            return ResponseEntity.badRequest().body("Error reading file: " + e.getMessage());
        }
    }
    
    @GetMapping("/{resource}")
    public ResponseEntity<String> getGenericResource(@PathVariable String resource) {
    	String fullPath = "/v1/" + resource;
    	return getResponse(fullPath);
    }

    @GetMapping("/{resource}/{resource2}")
    public ResponseEntity<String> getGenericResource1(@PathVariable String resource, 
    		@PathVariable String resource2) {
    	String fullPath = "/v1/"+resource+"/"+resource2;

    	return getResponse(fullPath);
    }
    

    @GetMapping("/{resource}/{resource2}/{resource3}")
    public ResponseEntity<String> getGenericResource2(@PathVariable String resource, 
    		@PathVariable String resource2,
    		@PathVariable String resource3) {
    	String fullPath = "/v1/"+resource+"/"+resource2 + "/" + resource3;

    	return getResponse(fullPath);
    }
    

    @PostMapping("/{resource}")
    public ResponseEntity<String> postGenericResource(@PathVariable String resource) {
    	String fullPath = "/v1/" + resource;
    	return getResponse(fullPath);
    }
    

    @PostMapping("/{resource}/{resource2}")
    public ResponseEntity<String> postGenericResource1(@PathVariable String resource, 
    		@PathVariable String resource2) {
    	String fullPath = "/v1/"+resource+"/"+resource2;

    	return getResponse(fullPath);
    }
    

    @PostMapping("/{resource}/{resource2}/{resource3}")
    public ResponseEntity<String> postGenericResource2(@PathVariable String resource, 
    		@PathVariable String resource2,
    		@PathVariable String resource3) {
    	String fullPath = "/v1/"+resource+"/"+resource2 + "/" + resource3;

    	return getResponse(fullPath);
    }*/
}
