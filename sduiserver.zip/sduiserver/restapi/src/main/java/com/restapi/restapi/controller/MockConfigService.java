package com.restapi.restapi.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.annotation.PostConstruct;

@Service
public class MockConfigService {



    @Value("${file.base-directory}")
    private String baseDirectory;
    
    private Map<String, Integer> endpointStatus = new HashMap<>();
    private String configFilePath;

    @PostConstruct
    public void init() {
    	configFilePath = baseDirectory + "endpointconfig.json";
        loadConfig();
    }

    private void loadConfig() {
        try {
            File file = new File(configFilePath);
            ObjectMapper mapper = new ObjectMapper();
            TypeReference<HashMap<String, Integer>> typeRef = new TypeReference<HashMap<String, Integer>>() {};
            endpointStatus = mapper.readValue(file, typeRef);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load configuration", e);
        }
    }

    public void updateResponseStatus(String endpoint, Integer status) {
        endpointStatus.put(endpoint, status);
        saveConfig();
    }

    private void saveConfig() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.writeValue(new File(configFilePath), endpointStatus);
        } catch (IOException e) {
            throw new RuntimeException("Failed to save configuration", e);
        }
    }

    public Optional<Integer> getResponseStatus(String endpoint) {
        return Optional.ofNullable(endpointStatus.get(endpoint));
    }
}