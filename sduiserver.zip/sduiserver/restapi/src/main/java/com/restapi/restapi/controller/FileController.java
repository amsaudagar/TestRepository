package com.restapi.restapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FileController {

    @Autowired
    private FileService fileService;

    @GetMapping("/screens/{filename}")
    public ResponseEntity<String> getFileContent(@PathVariable("filename") String filename) {
        try {
            String content = fileService.readScreenContent(filename);
            return ResponseEntity.ok(content);
        } catch (Exception e) {
            e.printStackTrace();  // Log the error
            return ResponseEntity.badRequest().body("Error reading file: " + e.getMessage());
        }
    }
    

    @GetMapping("/modules")
    public ResponseEntity<String> getModules(@RequestParam(name = "clientId", required = false, defaultValue = "mobiquity") String name) {
    	try {
            String content = fileService.readFileContent("/modules/modules");
            return ResponseEntity.ok(content);
        } catch (Exception e) {
            e.printStackTrace();  // Log the error
            return ResponseEntity.badRequest().body("Error reading file: " + e.getMessage());
        }
    }
    

    @GetMapping("/modules/{moduleName}")
    public ResponseEntity<String> getSpecificModule(@PathVariable String moduleName) {
    	try {
            String content = fileService.readFileContent("/modules/"+moduleName);
            return ResponseEntity.ok(content);
        } catch (Exception e) {
            e.printStackTrace();  // Log the error
            return ResponseEntity.badRequest().body("Error reading file: " + e.getMessage());
        }
    }


    @GetMapping("/configs")
    public ResponseEntity<String> getConfiguration(@RequestParam(name = "clientId", required = false, defaultValue = "mobiquity") String name) {
    	try {
            String content = fileService.readFileContent("/configs/configs");
            return ResponseEntity.ok(content);
        } catch (Exception e) {
            e.printStackTrace();  // Log the error
            return ResponseEntity.badRequest().body("Error reading file: " + e.getMessage());
        }
    }

}
